import java.util.ArrayList;
import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Simple Glossary with links.
 *
 * @author Kelland Goodin
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Compares Strings in lexicographic order.
     */
    private static class StringLex implements Comparator<String> {
        @Override

        public int compare(String o1, String o2) {
            return o1.compareTo(o2);

        }
    }

    /**
     * Returns an Arraylist containing lines read from the read File. If a line
     * is empty, the String is marked with "*" to indicate separation.
     *
     * @param readingFile
     *            source of strings
     * @return Arraylist of Strings containing text from the read File
     */
    private static ArrayList<String> makeArray(SimpleReader readingFile) {

        ArrayList<String> line = new ArrayList<String>();

        line.add("*");

        while (!readingFile.atEOS()) {
            String nextLine = readingFile.nextLine();
            if (nextLine.isEmpty()) {
                nextLine = "*";
            }
            line.add(nextLine);
        }
        line.add("*");

        return line;
    }

    /**
     * Returns an Arraylist of positions of characters separating the lines
     *
     * @param lines
     *            Arraylists containing separators between terms and
     *            definitions.
     * @return ArrayList of integer positions of separators.
     */
    private static ArrayList<Integer> position(ArrayList<String> lines) {

        ArrayList<Integer> separators = new ArrayList<Integer>();

        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).equals("*")) {
                separators.add(i);
            }
        }
        return separators;
    }

    /**
     * Returns word queues from lines.
     *
     * @param lines
     *            incoming Arraylist containing terms
     * @param positions
     *            incoming Arraylist to determine location of terms in lines
     * @return queue of sorted terms from lines
     */
    private static Queue<String> words(ArrayList<String> lines,
            ArrayList<Integer> positions) {

        Queue<String> words = new Queue1L<String>();

        for (int i = 0; i < positions.size() - 1; i++) {
            String word = lines.get(positions.get(i) + 1);
            words.enqueue(word);
        }
        return words;
    }

    /**
     * Returns a definition queues from lines.
     *
     * @param lines
     *            incoming Arraylist containing definitions
     * @param positions
     *            incoming Arraylist to determine location of definitions in
     *            lines
     * @return queue of sorted definitions from lines
     */
    private static Queue<String> definitions(ArrayList<String> lines,
            ArrayList<Integer> positions) {

        Queue<String> definitions = new Queue1L<String>();

        for (int i = 0; i < positions.size() - 1; i++) {
            String def = " ";
            for (int j = positions.get(i) + 2; j < positions.get(i + 1); j++) {
                if (j == positions.get(i) + 2) {
                    def += lines.get(j);
                } else {
                    def += " " + lines.get(j);
                }
            }
            definitions.enqueue(def);
        }
        return definitions;
    }

    /**
     * Generates a map of corresponding words and definition of those words
     *
     * @param words
     *            incoming list of words
     * @param definitions
     *            incoming list of definitions
     * @return map of words & defs together
     */
    private static Map<String, String> initializeMap(Queue<String> terms,
            Queue<String> definitions) {

        Map<String, String> words = new Map1L<>();

        int length = terms.length();

        for (int i = 0; i < length; ++i) {
            String term = terms.dequeue();
            String definition = definitions.dequeue();
            words.add(term, definition);
        }
        return words;
    }

    /**
     * Takes each pair of elements from initiliazeMap, places them in an index
     * of alphabetical order, and sorts in lexicographical order.
     *
     * @param termsDefs
     *            incoming words with their definitions
     * @return queue of strings in "word:definition" format in alphabetical
     *         order.
     */
    private static Queue<String> alphabetize(Map<String, String> termsDefs) {

        Queue<String> abc = new Queue1L<>();

        Map<String, String> tmp = termsDefs.newInstance();
        tmp.transferFrom(termsDefs);

        while (tmp.size() > 0) {
            Map.Pair<String, String> pair = tmp.removeAny();
            String paired = pair.key() + ":" + pair.value();

            abc.enqueue(paired);
            termsDefs.add(pair.key(), pair.value());
        }

        Comparator<String> abc2 = new StringLex();
        abc.sort(abc2);

        return abc;
    }

    /**
     * Generates an HTML index table of contents of words in a list in the file
     * specified in the output code
     *
     * @param list
     *            list of words
     * @param out
     *            output
     */
    public static void outputHTML(SimpleWriter out, Queue<String> list) {

        out.println("<html>");
        out.println("<head>");
        out.println("<title>~Glossary~</title>");
        out.println("<head/>");
        out.println("<body>");
        out.println("<h2>Glossary</h2>");
        out.println("<hr>");
        out.println("<h3>Index</h3>");
        out.println("<ul>");

        int length = list.length();
        Queue<String> tmp = list.newInstance();
        tmp.transferFrom(list);

        for (int i = 0; i < length; ++i) {
            String line = tmp.dequeue();
            String words = line.substring(0, line.indexOf(":"));

            out.println("<li>");
            out.println("<a href=\"" + words + ".html\">" + words + "</a");
            out.println("</li>");

            list.enqueue(line);
        }

        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Generates an HTML page for the definition of the words in the file
     * specified in the output.
     *
     * @param word
     *            the glossary page
     * @param wordCheck
     *            Queue that checks for the words that need to have link
     * @param out
     *            output
     */
    private static void wordHTML(String word, SimpleWriter out,
            Queue<String> wordCheck) {

        String words = word.substring(0, word.indexOf(":"));
        String def = word.substring(word.indexOf(":") + 1);

        out.println("<html>");
        out.println("<head>");
        out.println("<title>" + words + "</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>");
        out.println("<b>");
        out.println("<i>");
        out.println("<font color=\"red\">" + words + "</font>");
        out.println("</i>");
        out.println("</b>");
        out.println("</h2>");

        out.println("<blockquote>" + checkHL(def, wordCheck) + "</blockquote>");

        out.println("<hr>");
        out.println("<p>");
        out.println("Return to");
        out.println("<a href=\"" + checkHL("index.html", wordCheck)
                + "\">index</a>");
        out.println(".");
        out.println("</p>");
        out.println("</body>");
        out.println("</html>");

    }

    /**
     * Returns the definition of a word with hyperlinking if the definition
     * contains a term in the glossary.
     *
     * @param definition
     *            checking
     * @param terms
     *            list in the glossary
     *
     * @return string holding the defnintion with appropriate syntax
     */
    private static String checkHL(String definition, Queue<String> terms) {

        Queue<String> tmp = terms.newInstance();
        tmp.transferFrom(terms);

        while (tmp.length() > 0) {
            String check = tmp.dequeue();
            if (definition.contains(check)) {
                definition = definition.replace(check,
                        "<a href=\"" + check + ".html\">" + check + "</a>");
            }
            terms.enqueue(check);
        }
        return definition;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter input file name(*.txt): ");
        String fileName = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(fileName);

        out.print("Enter folder name output files(*.html): ");
        String outputName = in.nextLine();
        SimpleWriter indexOut = new SimpleWriter1L(outputName + ".html");

        ArrayList<String> line = makeArray(inFile);

        ArrayList<Integer> separators = position(line);

        Queue<String> words = words(line, separators);
        Queue<String> words2 = words(line, separators);
        Queue<String> definitions = definitions(line, separators);

        Map<String, String> termsAndDefs = initializeMap(words, definitions);

        Queue<String> abc = alphabetize(termsAndDefs);

        outputHTML(indexOut, abc);

        while (abc.length() > 0) {
            String wordDef = abc.dequeue();
            String word = wordDef.substring(0, wordDef.indexOf(":"));

            SimpleWriter pageOutprint = new SimpleWriter1L(word);

            wordHTML(wordDef, pageOutprint, words2);
            pageOutprint.close();
        }
        in.close();
        out.close();
        inFile.close();
        indexOut.close();
    }
}
